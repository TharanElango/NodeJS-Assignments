const fs = require('fs');

fs.readFile('ReadFile.json', (err, data) => {
    if (err) throw err;
    let testr = JSON.parse(data);
console.log('Read ReadFile JSON file');  
    console.log(testr);
});