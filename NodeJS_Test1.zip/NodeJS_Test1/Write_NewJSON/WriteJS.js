const fs = require('fs');

let Employee = { 
Org_name : 'Wipro LTD',
Emp_name : 'Tharan Elango'
};
 
let data = JSON.stringify(Employee, null, 2);

fs.writeFile('DataWrite.json', data, (err) => {
    if (err) throw err;
    console.log('Data written to new DataWrite JSON file');
    let testw = JSON.parse(data);
    console.log(testw);
});