const fs = require('fs');

fs.readFile('RWfile.json', (err, data) => {
    if (err) throw err;
    let testr = JSON.parse(data);
console.log('Read RWFile JSON file');   
 console.log(testr);
});