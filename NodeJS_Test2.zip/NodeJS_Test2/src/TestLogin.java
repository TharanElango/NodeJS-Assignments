import java.util.Scanner;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
public class TestLogin 
 {
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "E:\\Selenium Java\\chromedriver_win32\\chromedriver.exe");

		//Initialize browser
		WebDriver driver=new ChromeDriver();

		//Open Google
		driver.get("https://www.opencart.com/");
		System.out.println("Launch : "+driver.getTitle());
		//Maximize browser
//		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[@id='navbar-collapse-header']/div/a[1]")).click();
		System.out.println("Page : "+driver.getTitle());
//		driver.findElement(By.xpath("//*[@id='tsf']/div[2]/div[1]/div[3]/center/input[1]")).click();
		Thread.sleep(3000);
		Scanner in = new Scanner(System.in);
		System.out.println("Enter Email ID : ");
		String emailID = in.next();		
		WebElement email = driver.findElement(By.xpath("//*[@id='input-email']"));							
        email.sendKeys(emailID);

		System.out.println("Enter Password : ");
		String Password = in.next();		
		WebElement Pwd = driver.findElement(By.xpath("//*[@id='input-password']"));							
		Pwd.sendKeys(Password);
		Thread.sleep(3000);
		System.out.println("Click on Login button");
        driver.findElement(By.xpath("//*[@id='account-login']/div[2]/div/div[1]/form/div[3]/div[1]/button[1]")).click();
		System.out.println("Check error -> ");
		Thread.sleep(3000);
		
		String data = driver.findElement(By.xpath("//*[@id='account-login']/div[2]/div[1]")).getText();
		System.out.println("Err data : "+data);
		String expect="No match for E-Mail and/or Password."+"\n"+"×";
		Assert.assertEquals(data, expect);
		System.out.println("Expected and Actual Message are matching...");  
		Thread.sleep(3000);
        
		System.out.println("Close");
			
		// Close browser
		driver.close();
	}
		}

