var webdriver = require('selenium-webdriver'),
By=webdriver.BY,
until=webdriver.until;

var driver = new webdriver.Builder()
.forBroser('chrome').build();

driver.get("https://www.opencart.com/");
driver.findElement(By.xpath("//*[@id='navbar-collapse-header']/div/a[1]")).click();
Thread.sleep(10000);
driver.close();
